<?php
/** Local overrides for this machine (MySQL root password). */
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'book_reservation');
define('DB_USER', 'root');
define('DB_PASS', '1234');
